from setuptools import setup

setup(name='stpwch',
      version='0.0.1',
      description='An alterative to make',
      url='http://github.com/Ehnryu/stopwatch',
      author='Ehnryu/Sakurai07',
      author_email='blzzardst0rm@gmail.com',
      license='MIT',
      packages=['stopwatch'],
    keywords=['stopwatch', 'tasks',"time"])